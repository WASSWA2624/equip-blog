export const blogScaffoldReady = true;
